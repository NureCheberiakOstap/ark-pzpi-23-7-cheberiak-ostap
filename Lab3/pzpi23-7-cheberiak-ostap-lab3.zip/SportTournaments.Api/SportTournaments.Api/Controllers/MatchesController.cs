using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SportTournaments.Api.Data;
using SportTournaments.Api.Dtos;
using SportTournaments.Api.Entities;

namespace SportTournaments.Api.Controllers;

[ApiController]
[Route("api")]
public class MatchesController : BaseAuthController
{
    public MatchesController(ApplicationDbContext db) : base(db) { }

    // Список матчів турніру
    // GET /api/tournaments/{tournamentId}/matches
    [HttpGet("tournaments/{tournamentId:guid}/matches")]
    public async Task<IActionResult> GetTournamentMatches(Guid tournamentId)
    {
        var exists = await _db.Tournaments.AsNoTracking().AnyAsync(t => t.Id == tournamentId);
        if (!exists) return NotFound("Tournament not found.");

        var matches = await _db.Matches
            .AsNoTracking()
            .Where(m => m.TournamentId == tournamentId)
            .OrderBy(m => m.Round)
            .ThenBy(m => m.ScheduledAt)
            .Select(m => new
            {
                m.Id,
                m.Round,
                m.HomeTeamId,
                m.AwayTeamId,
                m.ScheduledAt,
                m.Location,
                m.Status
            })
            .ToListAsync();

        return Ok(matches);
    }

    // Внесення результату матчу
    // POST /api/matches/{matchId}/result
    [HttpPost("matches/{matchId:guid}/result")]
    public async Task<IActionResult> EnterResult(Guid matchId, CreateMatchResultRequest request)
    {
        var auth = await AuthorizeAsync("Organizer", "Admin", "Judge");
        if (auth != null) return auth;

        var user = (User)HttpContext.Items["User"]!;

        var match = await _db.Matches
            .Include(m => m.Result)
            .FirstOrDefaultAsync(m => m.Id == matchId);

        if (match is null) return NotFound("Match not found.");
        if (match.Status == "canceled") return BadRequest("Match is canceled.");

        if (match.Result != null) return Conflict("Result already exists.");

        var winnerTeamId = request.HomeScore == request.AwayScore
            ? (Guid?)null
            : (request.HomeScore > request.AwayScore ? match.HomeTeamId : match.AwayTeamId);

        var result = new MatchResult
        {
            MatchId = matchId,
            HomeScore = request.HomeScore,
            AwayScore = request.AwayScore,
            WinnerTeamId = winnerTeamId,
            EnteredByUserId = user.Id
        };

        match.Status = "finished";
        _db.MatchResults.Add(result);
        await _db.SaveChangesAsync();

        return Ok(result);
    }
}
