using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SportTournaments.Api.Data;
using SportTournaments.Api.Dtos;
using SportTournaments.Api.Services;

namespace SportTournaments.Api.Controllers;

[ApiController]
[Route("api/admin")]
public class AdminController : BaseAuthController
{
    private readonly AdminDataService _adminData;

    public AdminController(ApplicationDbContext db, AdminDataService adminData) : base(db)
    {
        _adminData = adminData;
    }

    // ===== Users =====

    [HttpGet("users")]
    public async Task<IActionResult> GetUsers()
    {
        var auth = await AuthorizeAsync("Admin");
        if (auth != null) return auth;

        var users = await _db.Users
            .Include(u => u.Role)
            .AsNoTracking()
            .OrderByDescending(u => u.CreatedAt)
            .Select(u => new
            {
                u.Id,
                u.Name,
                u.Email,
                Role = u.Role.Name,
                u.IsActive,
                u.CreatedAt
            })
            .ToListAsync();

        return Ok(users);
    }

    [HttpPatch("users/{id:guid}/deactivate")]
    public async Task<IActionResult> DeactivateUser(Guid id)
    {
        var auth = await AuthorizeAsync("Admin");
        if (auth != null) return auth;

        var user = await _db.Users.FirstOrDefaultAsync(u => u.Id == id);
        if (user is null) return NotFound();

        user.IsActive = false;
        await _db.SaveChangesAsync();

        return Ok(new { user.Id, user.IsActive });
    }

    [HttpPatch("users/{id:guid}/activate")]
    public async Task<IActionResult> ActivateUser(Guid id)
    {
        var auth = await AuthorizeAsync("Admin");
        if (auth != null) return auth;

        var user = await _db.Users.FirstOrDefaultAsync(u => u.Id == id);
        if (user is null) return NotFound();

        user.IsActive = true;
        await _db.SaveChangesAsync();

        return Ok(new { user.Id, user.IsActive });
    }

    // ===== Export / Import =====

    [HttpGet("export")]
    public async Task<IActionResult> Export()
    {
        var auth = await AuthorizeAsync("Admin");
        if (auth != null) return auth;

        var dto = await _adminData.ExportAsync();
        return Ok(dto);
    }

    [HttpPost("import")]
    public async Task<IActionResult> Import([FromBody] AdminExportDto dto)
    {
        var auth = await AuthorizeAsync("Admin");
        if (auth != null) return auth;

        var (ok, error) = await _adminData.ImportAsync(dto);
        if (!ok) return BadRequest(error);

        return Ok("Imported.");
    }
}
