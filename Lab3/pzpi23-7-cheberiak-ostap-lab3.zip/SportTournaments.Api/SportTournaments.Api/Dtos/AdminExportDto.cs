namespace SportTournaments.Api.Dtos;

public class AdminExportDto
{
    public List<RoleExportDto> Roles { get; set; } = new();
    public List<UserExportDto> Users { get; set; } = new();
    public List<TournamentExportDto> Tournaments { get; set; } = new();
    public List<TeamExportDto> Teams { get; set; } = new();
    public List<RegistrationExportDto> Registrations { get; set; } = new();
    public List<MatchExportDto> Matches { get; set; } = new();
    public List<MatchResultExportDto> MatchResults { get; set; } = new();
}

public class RoleExportDto
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
}

public class UserExportDto
{
    public Guid Id { get; set; }
    public string Name { get; set; } = null!;
    public string Email { get; set; } = null!;
    public int RoleId { get; set; }
    public bool IsActive { get; set; }
    public DateTime CreatedAt { get; set; }
}

public class TournamentExportDto
{
    public Guid Id { get; set; }
    public string Title { get; set; } = null!;
    public string SportType { get; set; } = null!;
    public string Format { get; set; } = null!;
    public DateTime StartDate { get; set; }
    public DateTime? EndDate { get; set; }
    public string Status { get; set; } = null!;
    public Guid OrganizerUserId { get; set; }
    public DateTime CreatedAt { get; set; }
}

public class TeamExportDto
{
    public Guid Id { get; set; }
    public string Name { get; set; } = null!;
    public Guid CaptainUserId { get; set; }
    public DateTime CreatedAt { get; set; }
}

public class RegistrationExportDto
{
    public Guid Id { get; set; }
    public Guid TournamentId { get; set; }
    public Guid TeamId { get; set; }
    public Guid ApplicantUserId { get; set; }
    public string Status { get; set; } = null!;
    public DateTime CreatedAt { get; set; }
}

public class MatchExportDto
{
    public Guid Id { get; set; }
    public Guid TournamentId { get; set; }
    public int Round { get; set; }
    public Guid HomeTeamId { get; set; }
    public Guid AwayTeamId { get; set; }
    public DateTime ScheduledAt { get; set; }
    public string? Location { get; set; }
    public string Status { get; set; } = null!;
}

public class MatchResultExportDto
{
    public Guid MatchId { get; set; }
    public int HomeScore { get; set; }
    public int AwayScore { get; set; }
    public Guid? WinnerTeamId { get; set; }
    public Guid EnteredByUserId { get; set; }
    public DateTime EnteredAt { get; set; }
}
