namespace SportTournaments.Api.Dtos;

public class CreateMatchResultRequest
{
    public int HomeScore { get; set; }
    public int AwayScore { get; set; }
}
