using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using SportTournaments.Api.Data;
using SportTournaments.Api.Dtos;
using SportTournaments.Api.Entities;
using SportTournaments.Api.Helpers;

namespace SportTournaments.Api.Services;

public class AdminDataService
{
    private readonly ApplicationDbContext _db;
    public AdminDataService(ApplicationDbContext db) => _db = db;

    public async Task<AdminExportDto> ExportAsync()
    {
        var dto = new AdminExportDto
        {
            Roles = await _db.Roles.AsNoTracking()
                .OrderBy(r => r.Id)
                .Select(r => new RoleExportDto { Id = r.Id, Name = r.Name })
                .ToListAsync(),

            Users = await _db.Users.AsNoTracking()
                .OrderBy(u => u.CreatedAt)
                .Select(u => new UserExportDto
                {
                    Id = u.Id,
                    Name = u.Name,
                    Email = u.Email,
                    RoleId = u.RoleId,
                    IsActive = u.IsActive,
                    CreatedAt = u.CreatedAt
                })
                .ToListAsync(),

            Tournaments = await _db.Tournaments.AsNoTracking()
                .OrderBy(t => t.CreatedAt)
                .Select(t => new TournamentExportDto
                {
                    Id = t.Id,
                    Title = t.Title,
                    SportType = t.SportType,
                    Format = t.Format,
                    StartDate = t.StartDate,
                    EndDate = t.EndDate,
                    Status = t.Status,
                    OrganizerUserId = t.OrganizerUserId,
                    CreatedAt = t.CreatedAt
                })
                .ToListAsync(),

            Teams = await _db.Teams.AsNoTracking()
                .OrderBy(t => t.CreatedAt)
                .Select(t => new TeamExportDto
                {
                    Id = t.Id,
                    Name = t.Name,
                    CaptainUserId = t.CaptainUserId,
                    CreatedAt = t.CreatedAt
                })
                .ToListAsync(),

            Registrations = await _db.TournamentRegistrations.AsNoTracking()
                .OrderBy(r => r.CreatedAt)
                .Select(r => new RegistrationExportDto
                {
                    Id = r.Id,
                    TournamentId = r.TournamentId,
                    TeamId = r.TeamId,
                    ApplicantUserId = r.ApplicantUserId,
                    Status = r.Status,
                    CreatedAt = r.CreatedAt
                })
                .ToListAsync(),

            Matches = await _db.Matches.AsNoTracking()
                .OrderBy(m => m.ScheduledAt)
                .Select(m => new MatchExportDto
                {
                    Id = m.Id,
                    TournamentId = m.TournamentId,
                    Round = m.Round,
                    HomeTeamId = m.HomeTeamId,
                    AwayTeamId = m.AwayTeamId,
                    ScheduledAt = m.ScheduledAt,
                    Location = m.Location,
                    Status = m.Status
                })
                .ToListAsync(),

            MatchResults = await _db.MatchResults.AsNoTracking()
                .OrderBy(r => r.EnteredAt)
                .Select(r => new MatchResultExportDto
                {
                    MatchId = r.MatchId,
                    HomeScore = r.HomeScore,
                    AwayScore = r.AwayScore,
                    WinnerTeamId = r.WinnerTeamId,
                    EnteredByUserId = r.EnteredByUserId,
                    EnteredAt = r.EnteredAt
                })
                .ToListAsync()
        };

        return dto;
    }

    public async Task<(bool ok, string? error)> ImportAsync(AdminExportDto dto)
    {
        // ВАЖЛИВО: паролі не імпортуємо (в export їх немає).
        // Для "імпортованих" користувачів задаємо випадковий пароль та робимо їх неактивними
        // (щоб не було несанкціонованого входу).
        using var trx = await _db.Database.BeginTransactionAsync();

        try
        {
            // Roles (upsert by Id)
            foreach (var r in dto.Roles)
            {
                var role = await _db.Roles.FirstOrDefaultAsync(x => x.Id == r.Id);
                if (role == null)
                    _db.Roles.Add(new Role { Id = r.Id, Name = r.Name });
                else
                    role.Name = r.Name;
            }
            await _db.SaveChangesAsync();

            // Users (upsert by Id)
            foreach (var u in dto.Users)
            {
                var user = await _db.Users.FirstOrDefaultAsync(x => x.Id == u.Id);
                if (user == null)
                {
                    _db.Users.Add(new User
                    {
                        Id = u.Id,
                        Name = u.Name,
                        Email = u.Email,
                        RoleId = u.RoleId,
                        IsActive = false, // без пароля — деактивуємо
                        PasswordHash = PasswordHasher.Hash(Guid.NewGuid().ToString("N")),
                        CreatedAt = u.CreatedAt
                    });
                }
                else
                {
                    user.Name = u.Name;
                    user.Email = u.Email;
                    user.RoleId = u.RoleId;
                    user.IsActive = user.IsActive && u.IsActive; // не активуємо насильно
                }
            }
            await _db.SaveChangesAsync();

            // Tournaments
            foreach (var t in dto.Tournaments)
            {
                var entity = await _db.Tournaments.FirstOrDefaultAsync(x => x.Id == t.Id);
                if (entity == null)
                {
                    _db.Tournaments.Add(new Tournament
                    {
                        Id = t.Id,
                        Title = t.Title,
                        SportType = t.SportType,
                        Format = t.Format,
                        StartDate = t.StartDate,
                        EndDate = t.EndDate,
                        Status = t.Status,
                        OrganizerUserId = t.OrganizerUserId,
                        CreatedAt = t.CreatedAt
                    });
                }
                else
                {
                    entity.Title = t.Title;
                    entity.SportType = t.SportType;
                    entity.Format = t.Format;
                    entity.StartDate = t.StartDate;
                    entity.EndDate = t.EndDate;
                    entity.Status = t.Status;
                    entity.OrganizerUserId = t.OrganizerUserId;
                }
            }
            await _db.SaveChangesAsync();

            // Teams
            foreach (var t in dto.Teams)
            {
                var entity = await _db.Teams.FirstOrDefaultAsync(x => x.Id == t.Id);
                if (entity == null)
                {
                    _db.Teams.Add(new Team
                    {
                        Id = t.Id,
                        Name = t.Name,
                        CaptainUserId = t.CaptainUserId,
                        CreatedAt = t.CreatedAt
                    });
                }
                else
                {
                    entity.Name = t.Name;
                    entity.CaptainUserId = t.CaptainUserId;
                }
            }
            await _db.SaveChangesAsync();

            // Registrations
            foreach (var r in dto.Registrations)
            {
                var entity = await _db.TournamentRegistrations.FirstOrDefaultAsync(x => x.Id == r.Id);
                if (entity == null)
                {
                    _db.TournamentRegistrations.Add(new TournamentRegistration
                    {
                        Id = r.Id,
                        TournamentId = r.TournamentId,
                        TeamId = r.TeamId,
                        ApplicantUserId = r.ApplicantUserId,
                        Status = r.Status,
                        CreatedAt = r.CreatedAt
                    });
                }
                else
                {
                    entity.Status = r.Status;
                }
            }
            await _db.SaveChangesAsync();

            // Matches
            foreach (var m in dto.Matches)
            {
                var entity = await _db.Matches.FirstOrDefaultAsync(x => x.Id == m.Id);
                if (entity == null)
                {
                    _db.Matches.Add(new Match
                    {
                        Id = m.Id,
                        TournamentId = m.TournamentId,
                        Round = m.Round,
                        HomeTeamId = m.HomeTeamId,
                        AwayTeamId = m.AwayTeamId,
                        ScheduledAt = m.ScheduledAt,
                        Location = m.Location,
                        Status = m.Status
                    });
                }
                else
                {
                    entity.Round = m.Round;
                    entity.HomeTeamId = m.HomeTeamId;
                    entity.AwayTeamId = m.AwayTeamId;
                    entity.ScheduledAt = m.ScheduledAt;
                    entity.Location = m.Location;
                    entity.Status = m.Status;
                }
            }
            await _db.SaveChangesAsync();

            // MatchResults (key = MatchId)
            foreach (var r in dto.MatchResults)
            {
                var entity = await _db.MatchResults.FirstOrDefaultAsync(x => x.MatchId == r.MatchId);
                if (entity == null)
                {
                    _db.MatchResults.Add(new MatchResult
                    {
                        MatchId = r.MatchId,
                        HomeScore = r.HomeScore,
                        AwayScore = r.AwayScore,
                        WinnerTeamId = r.WinnerTeamId,
                        EnteredByUserId = r.EnteredByUserId,
                        EnteredAt = r.EnteredAt
                    });
                }
                else
                {
                    entity.HomeScore = r.HomeScore;
                    entity.AwayScore = r.AwayScore;
                    entity.WinnerTeamId = r.WinnerTeamId;
                    // EnteredBy/At не чіпаємо
                }
            }
            await _db.SaveChangesAsync();

            await trx.CommitAsync();
            return (true, null);
        }
        catch (Exception ex)
        {
            await trx.RollbackAsync();
            return (false, ex.Message);
        }
    }

    public static string ToJson(AdminExportDto dto)
        => JsonSerializer.Serialize(dto, new JsonSerializerOptions { WriteIndented = true });
}
