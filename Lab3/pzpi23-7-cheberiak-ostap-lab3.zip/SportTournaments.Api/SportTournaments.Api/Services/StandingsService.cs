using Microsoft.EntityFrameworkCore;
using SportTournaments.Api.Data;
using SportTournaments.Api.Dtos;

namespace SportTournaments.Api.Services;

public class StandingsService
{
    private readonly ApplicationDbContext _db;
    public StandingsService(ApplicationDbContext db) => _db = db;

    public async Task<(bool ok, string? error, List<StandingsRowDto>? table)> GetStandingsAsync(Guid tournamentId)
    {
        var exists = await _db.Tournaments.AsNoTracking().AnyAsync(t => t.Id == tournamentId);
        if (!exists) return (false, "Tournament not found.", null);

        // Беремо команди, які реально грають (approved)
        var approvedTeams = await _db.TournamentRegistrations
            .AsNoTracking()
            .Where(r => r.TournamentId == tournamentId && r.Status == "approved")
            .Select(r => r.TeamId)
            .Distinct()
            .ToListAsync();

        var teams = await _db.Teams
            .AsNoTracking()
            .Where(t => approvedTeams.Contains(t.Id))
            .Select(t => new { t.Id, t.Name })
            .ToListAsync();

        var rows = teams.ToDictionary(
            t => t.Id,
            t => new StandingsRowDto { TeamId = t.Id, TeamName = t.Name }
        );

        var finishedMatches = await _db.Matches
            .AsNoTracking()
            .Include(m => m.Result)
            .Where(m => m.TournamentId == tournamentId && m.Status == "finished" && m.Result != null)
            .ToListAsync();

        foreach (var m in finishedMatches)
        {
            var r = m.Result!;
            if (!rows.TryGetValue(m.HomeTeamId, out var home) || !rows.TryGetValue(m.AwayTeamId, out var away))
                continue;

            home.Played++; away.Played++;
            home.GoalsFor += r.HomeScore; home.GoalsAgainst += r.AwayScore;
            away.GoalsFor += r.AwayScore; away.GoalsAgainst += r.HomeScore;

            if (r.HomeScore > r.AwayScore)
            {
                home.Wins++; away.Losses++;
                home.Points += 3;
            }
            else if (r.HomeScore < r.AwayScore)
            {
                away.Wins++; home.Losses++;
                away.Points += 3;
            }
            else
            {
                home.Draws++; away.Draws++;
                home.Points += 1; away.Points += 1;
            }
        }

        var table = rows.Values
            .OrderByDescending(x => x.Points)
            .ThenByDescending(x => x.GoalDifference)
            .ThenByDescending(x => x.GoalsFor)
            .ThenBy(x => x.TeamName)
            .ToList();

        return (true, null, table);
    }
}
