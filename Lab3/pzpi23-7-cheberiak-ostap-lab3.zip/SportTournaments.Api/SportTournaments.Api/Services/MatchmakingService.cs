using Microsoft.EntityFrameworkCore;
using SportTournaments.Api.Data;
using SportTournaments.Api.Entities;

namespace SportTournaments.Api.Services;

public class MatchmakingService
{
    private readonly ApplicationDbContext _db;
    public MatchmakingService(ApplicationDbContext db) => _db = db;

    /// <summary>
    /// Генерує розклад матчів для турніру (наразі: round_robin).
    /// Матчі створюються тільки для команд із заявками status=approved.
    /// </summary>
    public async Task<(bool ok, string? error, int createdCount)> GenerateScheduleAsync(Guid tournamentId)
    {
        var t = await _db.Tournaments.AsNoTracking().FirstOrDefaultAsync(x => x.Id == tournamentId);
        if (t is null) return (false, "Tournament not found.", 0);

        if (t.Status == "closed") return (false, "Tournament is closed.", 0);

        var hasMatches = await _db.Matches.AnyAsync(m => m.TournamentId == tournamentId);
        if (hasMatches) return (false, "Schedule already generated.", 0);

        var teamIds = await _db.TournamentRegistrations
            .AsNoTracking()
            .Where(r => r.TournamentId == tournamentId && r.Status == "approved")
            .Select(r => r.TeamId)
            .ToListAsync();

        if (teamIds.Count < 2) return (false, "Need at least 2 approved teams.", 0);

        var format = (t.Format ?? "").Trim().ToLowerInvariant();
        if (format != "round_robin" && format != "round-robin" && format != "rr")
            return (false, "Only round_robin format is supported for schedule generation in this lab.", 0);

        // Circle method: якщо непарна кількість — додаємо BYE (Guid.Empty)
        var teams = teamIds.ToList();
        if (teams.Count % 2 == 1) teams.Add(Guid.Empty);

        int n = teams.Count;
        int rounds = n - 1;
        int matchesPerRound = n / 2;

        // Фіксуємо перший елемент, решту обертаємо
        var fixedTeam = teams[0];
        var rotating = teams.Skip(1).ToList();

        var matches = new List<Match>();

        for (int round = 1; round <= rounds; round++)
        {
            var roundTeams = new List<Guid> { fixedTeam };
            roundTeams.AddRange(rotating);

            for (int i = 0; i < matchesPerRound; i++)
            {
                var home = roundTeams[i];
                var away = roundTeams[n - 1 - i];

                if (home == Guid.Empty || away == Guid.Empty) continue; // BYE

                // Для різноманітності "дом/виїзд" інколи міняємо місцями
                bool swap = (round % 2 == 0);
                var homeId = swap ? away : home;
                var awayId = swap ? home : away;

                matches.Add(new Match
                {
                    TournamentId = tournamentId,
                    Round = round,
                    HomeTeamId = homeId,
                    AwayTeamId = awayId,
                    ScheduledAt = t.StartDate.Date.AddDays(round - 1).AddHours(18), // умовно 18:00
                    Status = "scheduled"
                });
            }

            // rotate: беремо останній і вставляємо на початок
            var last = rotating[^1];
            rotating.RemoveAt(rotating.Count - 1);
            rotating.Insert(0, last);
        }

        _db.Matches.AddRange(matches);
        var created = await _db.SaveChangesAsync();

        return (true, null, matches.Count);
    }
}
