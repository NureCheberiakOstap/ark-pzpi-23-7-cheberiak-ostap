using Microsoft.EntityFrameworkCore;
using SportTournaments.Api.Data;
using SportTournaments.Api.Services;
using System.Text.Json.Serialization;

namespace SportTournaments.Api
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            builder.Services.AddControllers().AddJsonOptions(o => {
                o.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles;
            });
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            // Дозволити CORS для демонстраційного фронтенду (ЛР3).
            // Якщо відкриваєш UI через той самий Kestrel (https://localhost:7050/) — CORS не потрібен.
            builder.Services.AddCors(options =>
            {
                options.AddPolicy("DevCors", policy =>
                {
                    policy
                        .WithOrigins("http://127.0.0.1:5500", "http://localhost:5500")
                        .AllowAnyHeader()
                        .AllowAnyMethod();
                });
            });


            builder.Services.AddDbContext<ApplicationDbContext>(opt =>
                opt.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

            // ЛР3: бізнес-логіка + адміністрування
            builder.Services.AddScoped<MatchmakingService>();
            builder.Services.AddScoped<StandingsService>();
            builder.Services.AddScoped<AdminDataService>();

            var app = builder.Build();

            using (var scope = app.Services.CreateScope())
            {
                var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
                DbSeeder.SeedRolesAsync(db).GetAwaiter().GetResult();
            }

            app.UseSwagger();
            app.UseSwaggerUI();

            app.UseCors("DevCors");


            app.MapControllers();

            app.UseStaticFiles();

            // щоб при відкритті http://localhost:XXXX/ відкривався наш фронтенд
            app.MapFallbackToFile("app/index.html");


            app.Run();

        }
    }
}