function renderSessionInfo(container) {
  const token = getToken();
  const apiBase = getApiBase() || "(same-origin)";

  const tokenHtml = token
    ? `<div>Token: <code class="small">${token.slice(0, 16)}…</code></div><div>Статус: авторизовано</div>`
    : `<div>Token: <b>немає</b></div><div>Статус: неавторизовано</div>`;

  container.innerHTML = `
    <div>API base: <code class="small">${apiBase}</code></div>
    ${tokenHtml}
  `;
}
