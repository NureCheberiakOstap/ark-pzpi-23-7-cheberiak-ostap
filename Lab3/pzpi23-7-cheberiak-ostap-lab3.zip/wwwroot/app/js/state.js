const SELECTED_TOURNAMENT_KEY = "selectedTournamentId";

function getSelectedTournamentId() {
  return localStorage.getItem(SELECTED_TOURNAMENT_KEY) || "";
}

function setSelectedTournamentId(id) {
  if (!id) localStorage.removeItem(SELECTED_TOURNAMENT_KEY);
  else localStorage.setItem(SELECTED_TOURNAMENT_KEY, id);
}
