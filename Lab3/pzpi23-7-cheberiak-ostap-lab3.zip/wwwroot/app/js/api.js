// API base URL.
// Рекомендовано відкривати фронтенд через Kestrel (https://localhost:7050/),
// тоді API_BASE можна залишити порожнім (same-origin).
// Якщо відкриваєш фронтенд через Live Server/інший порт — задай API base в налаштуваннях UI
// або в localStorage ключем "apiBase", напр.: https://localhost:7050
function getApiBase() {
  return localStorage.getItem("apiBase") || "";
}

function setApiBase(url) {
  localStorage.setItem("apiBase", url || "");
}

function clearApiBase() {
  localStorage.removeItem("apiBase");
}

function normalizeBase(base) {
  if (!base) return "";
  return base.endsWith("/") ? base.slice(0, -1) : base;
}

function apiUrl(path) {
  const base = normalizeBase(getApiBase());
  if (!base) return path; // same-origin
  if (!path.startsWith("/")) path = "/" + path;
  return base + path;
}

function getToken() {
  return localStorage.getItem("authToken") || "";
}

function setToken(token) {
  localStorage.setItem("authToken", token);
}

function clearToken() {
  localStorage.removeItem("authToken");
}

function authHeaders() {
  const h = { "Content-Type": "application/json" };
  const token = getToken();
  if (token) h["X-Auth-Token"] = token;
  return h;
}

async function apiFetch(path, { method = "GET", body = null, withAuth = true } = {}) {
  const headers = withAuth ? authHeaders() : { "Content-Type": "application/json" };

  const resp = await fetch(apiUrl(path), {
    method,
    headers,
    body: body ? JSON.stringify(body) : null
  });

  const text = await resp.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }

  if (!resp.ok) {
    const msg = typeof data === "string" ? data : (data?.message || data?.error || JSON.stringify(data));
    throw new Error(`HTTP ${resp.status}: ${msg}`);
  }

  return data;
}

// helper для UI
function el(tag, className, text) {
  const e = document.createElement(tag);
  if (className) e.className = className;
  if (text !== undefined && text !== null) e.textContent = text;
  return e;
}
